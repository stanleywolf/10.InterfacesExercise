﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IBirthdable:IIdentable
{
     string  Birthday { get; set; }
}