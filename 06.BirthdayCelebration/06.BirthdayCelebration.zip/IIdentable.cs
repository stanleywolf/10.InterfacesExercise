﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IIdentable
{
    string Name { get; set; }
    //string ID { get; set; }
}