﻿using System;
using System.Collections.Generic;
using System.Text;
using DungeonsAndCodeWizards.Models;
using DungeonsAndCodeWizards.Models.Characters;

namespace DungeonsAndCodeWizards.Factories
{
   public class CharacterFactory
    {
        public Character CreateCharacter(string[] args)
        {
            string enumType = args[0];

            bool validEnum = Enum.TryParse(typeof(Faction), enumType, out object weatherObj);

            if (!validEnum)
            {
                throw new ArgumentException(String.Format(OutputMessages.InvalidFaction, args[0]));
            }
            Faction faction = (Faction)weatherObj;
            //var this.track.Weather = weather;
            string charType = args[1];
            var name = args[2];
            if (name == null)
            {
                throw new ArgumentException();
            }
                    

            switch (charType)
            {
                case "Warrior":
                    return new Warrior(name,faction);
                case "Cleric":
                    return new Cleric(name,faction);
                    default:
                        throw new ArgumentException(String.Format(OutputMessages.InvalidCharacterType, charType));
            }
        }
    }
}
