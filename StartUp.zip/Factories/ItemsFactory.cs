﻿using System;
using System.Collections.Generic;
using System.Text;
using DungeonsAndCodeWizards.Models;
using DungeonsAndCodeWizards.Models.Items;

namespace DungeonsAndCodeWizards.Factories
{
   public class ItemsFactory
    {
        public Item CreateItem(string itenName)
        {
            if (itenName == null)
            {
                throw new ArgumentException();
            }
            switch (itenName)
            {
                case "HealthPotion":
                    return new HealthPotion();
                case "PoisonPotion":
                    return new PoisonPotion();
                case "ArmorRepairKit":
                    return new ArmorRepairKit();
                    default:
                    throw new ArgumentException($"Invalid item \"{ itenName}\"S!");                    
            }
        }
    }
}
