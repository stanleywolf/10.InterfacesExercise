﻿using System;
using System.Linq;
using DungeonsAndCodeWizards.BussinesLogic;

namespace DungeonsAndCodeWizards
{
	public class StartUp
	{
		// DO NOT rename this file's namespace or class name.
		// However, you ARE allowed to use your own namespaces (or no namespaces at all if you prefer) in other classes.
		public static void Main(string[] args)
		{
		    var master = new DungeonMaster();

		    bool gameOver = false;
		    while (!gameOver)
		    {
		        try
		        {
		            var argsInput = Console.ReadLine().Split();
		            var commandArgs = argsInput.Skip(1).ToArray();

		            switch (argsInput[0])
		            {
		                case "JoinParty":
		                    Console.WriteLine(master.JoinParty(commandArgs));
		                    break;
		                case "AddItemToPool":
		                    Console.WriteLine(master.AddItemToPool(commandArgs));
		                    break;
		                case "PickUpItem":
		                    Console.WriteLine(master.PickUpItem(commandArgs));
		                    break;
		                case "UseItem":
		                    Console.WriteLine(master.UseItem(commandArgs));
		                    break;
		                case "Attack":
		                    Console.WriteLine(master.Attack(commandArgs));
		                    break;
		                case "Heal":
		                    Console.WriteLine(master.Heal(commandArgs));
		                    break;
		                case "EndTurn":
		                    Console.WriteLine(master.EndTurn(commandArgs));
		                    break;
		                case "IsGameOver":
		                    master.IsGameOver();    
		                    break;
		                default:
		                    break;

		            }
                }
		        catch (Exception e)
		        {
		            Console.WriteLine(e.Message);
		           
		        }
		    }
		}
	}
}