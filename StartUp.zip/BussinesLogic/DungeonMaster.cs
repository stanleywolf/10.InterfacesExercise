﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DungeonsAndCodeWizards.Factories;
using DungeonsAndCodeWizards.Models;
using DungeonsAndCodeWizards.Models.Characters;

namespace DungeonsAndCodeWizards.BussinesLogic
{
    class DungeonMaster
    {
        public DungeonMaster()
        {
            this.characterFactory = new CharacterFactory();
            this.itemsFactory = new ItemsFactory();
            this.characters = new List<Character>();
            this.poolItems = new Stack<Item>();
            this.NumOfRounds = 0;
            this.isOver = false;
        }

        private CharacterFactory characterFactory;
        private ItemsFactory itemsFactory;
        private List<Character> characters;
        protected Stack<Item> poolItems;
        private int NumOfRounds { get; set; }
        private bool isOver { get; set; }

        public string JoinParty(string[] args)
        {
            Character character = characterFactory.CreateCharacter(args);
            characters.Add(character);
            return $"{character.Name} joined the party!";
        }

        public string AddItemToPool(string[] args)
        {
            Item item = itemsFactory.CreateItem(args[0]);
            poolItems.Push(item);
            return $"{args[0]} added to pool.";
        }

        public string PickUpItem(string[] args)
        {
            Character character = characters.FirstOrDefault(c => c.Name == args[0]);
            if (character == null)
            {
                throw new ArgumentException($"Character {character.Name} not found!");
            }
            if (poolItems.Count == 0)
            {
                throw new InvalidOperationException($"No items left in pool!");
            }
            var itemName = poolItems.Peek().GetType().Name;
            var item = poolItems.Pop();
            character.Bag.AddItem(item);
            return $"{character.Name} picked up {itemName}!";
        }

        public string UseItem(string[] args)
        {
            var character = characters.FirstOrDefault(c => c.Name == args[0]);
            var item = character.Bag.Items.FirstOrDefault(i => nameof(i) == args[1]);
            if (item == null)
            {
                throw new ArgumentException();
            }
            if (character == null)
            {
                throw new ArgumentException($"Character {args[0]} not found!");
            }
            
            character.Bag.Items.Remove(item);
            return $"{character.Name} used {args[1]}.";
        }

        public string UseItemOn(string[] args)
        {
            var attacker = characters.FirstOrDefault(c => c.Name == args[0]);
            var reciever = characters.FirstOrDefault(c => c.Name == args[1]);          
            var item = attacker.Bag.Items.FirstOrDefault(i => nameof(i) == args[2]);

            if (attacker.GetType().Name == "Warrior")
            {
              
            }
            return null;

        }

        public string GiveCharacterItem(string[] args)
        {
            throw new NotImplementedException();
        }

        public string GetStats()
        {
            throw new NotImplementedException();
        }

        public string Attack(string[] args)
        {
            var attacker = characters.FirstOrDefault(c => c.Name == args[0]);
            var receiver = characters.FirstOrDefault(c => c.Name == args[1]);
            if (attacker == null || receiver == null)
            {
                throw new ArgumentException($"{attacker.Name} cannot attack!");
            }
            var sb = new StringBuilder();
            sb.AppendLine(
                $"{attacker.Name} attacks {receiver.Name} for {attacker.AbilityPoints} hit points! {receiver.Name} has {receiver.Health}/{receiver.BaseHealth} HP and {receiver.Armor}/{receiver.BaseArmor} AP left!");

            if (receiver.Health <= 0)
            {
                sb.AppendLine($"“{receiver.Name} is dead!");
            }
            return sb.ToString().TrimEnd();
        }

        public string Heal(string[] args)
        {
            var healer = characters.FirstOrDefault(c => c.Name == args[0]);
            var receiver = characters.FirstOrDefault(c => c.Name == args[1]);

            if (healer.GetType().Name != "Cleric")
            {
                throw new ArgumentException($"{healer} cannot heal!");
            }
            return
                $"{healer.Name} heals {receiver.Name} for {healer.AbilityPoints}! {receiver.Name} has {receiver.Health} health now!";
        }

        public string EndTurn(string[] args)
        {
            var stringBuilder = new StringBuilder();
            if (characters.Count < 2)
            {
                this.NumOfRounds++;
            }

            foreach (var character in characters)
            {
                var health = character.Health;
                character.Rest();

                stringBuilder.AppendLine($"“{character.Name} rests ({health} => {character.Health})");
            }
            return stringBuilder.ToString().TrimEnd();
        }

        public bool IsGameOver()
        {
            if (NumOfRounds > 1)
            {
                isOver = true;
                
            }
            return isOver;
        }

    }
}
