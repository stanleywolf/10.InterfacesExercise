﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards
{
   public static class OutputMessages
   {
       public static string CharacterIsAlive => "Must be alive to perform this action!";
       public static string FullBag => "Bag is full!";
       public static string NameNull => "Name cannot be null or whitespace!";
       public static string EmptyBag => "Bag is full!";
       public static string NoNameItenBag => "No item with name {0} in bag!";
        public static string InvalidCharacterType => "Invalid character type \"{0}\"!";
       public static string InvalidItem => "Invalid item type \"{0}\"!";
       public static string InvalidFaction => "Invalid faction \"{0}\"!";

   }
}
