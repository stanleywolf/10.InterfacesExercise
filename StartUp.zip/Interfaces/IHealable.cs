﻿using System;
using System.Collections.Generic;
using System.Text;
using DungeonsAndCodeWizards.Models;

namespace DungeonsAndCodeWizards.Interfaces
{
   public interface IHealable
    {
       void Heal(Character character);
    }
}
