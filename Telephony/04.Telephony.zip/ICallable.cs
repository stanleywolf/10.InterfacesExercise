﻿using System;
using System.Collections.Generic;
using System.Text;

public interface ICallable
{
    string Calling(string number);
}